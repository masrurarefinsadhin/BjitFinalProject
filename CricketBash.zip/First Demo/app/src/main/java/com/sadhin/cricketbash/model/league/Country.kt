package com.sadhin.cricketbash.model.league

data class Country(
    val continent_id: Int?,
    val id: Int?,
    val image_path: String?,
    val name: String?,
    val resource: String?,
    val updated_at: String?
)