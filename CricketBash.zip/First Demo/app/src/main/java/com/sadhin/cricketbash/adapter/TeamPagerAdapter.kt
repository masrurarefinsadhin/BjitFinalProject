package com.sadhin.cricketbash.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.sadhin.cricketbash.ui.RankFragment
import com.sadhin.cricketbash.ui.RankThreeFragment
import com.sadhin.cricketbash.ui.RankTwoFragment

private const val NUMS_TAB = 3
class TeamPagerAdapter (fragmentManager: FragmentManager, lifecycle: Lifecycle):
    FragmentStateAdapter(fragmentManager, lifecycle) {
    override fun getItemCount(): Int { return NUMS_TAB }

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> RankFragment()
            1 -> RankTwoFragment()
            else -> RankThreeFragment()

        }
    }
}