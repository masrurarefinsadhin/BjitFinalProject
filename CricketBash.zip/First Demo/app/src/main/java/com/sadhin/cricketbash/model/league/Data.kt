package com.sadhin.cricketbash.model.league

data class Data(
    val code: String?,
    val country: Country?,
    val country_id: Int?,
    val id: Int?,
    val image_path: String?,
    val name: String?,
    val resource: String?,
    val season_id: Int?,
    val seasons: List<Season>?,
    val type: String?,
    val updated_at: String?
)