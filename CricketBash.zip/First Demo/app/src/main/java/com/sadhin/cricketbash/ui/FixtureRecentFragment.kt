package com.sadhin.cricketbash.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sadhin.cricketbash.adapter.FixtureRecentAdapter
import com.sadhin.cricketbash.databinding.FragmentFixtureRecentBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class FixtureRecentFragment : Fragment() {
    private var _binding: FragmentFixtureRecentBinding?=null
    private  val binding get()=_binding!!
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewModel: FixtureViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_fixture_recent, container, false)
        _binding=FragmentFixtureRecentBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView=binding.recyclerViewFixtureRecent
        recyclerView.layoutManager= LinearLayoutManager(context)
        val adapter= FixtureRecentAdapter(requireContext(),viewModel)
        recyclerView.adapter=adapter
        viewModel.fixtureRecent.observe(viewLifecycleOwner){ adapter.setFixture(it) }
    }
    companion object {}
}