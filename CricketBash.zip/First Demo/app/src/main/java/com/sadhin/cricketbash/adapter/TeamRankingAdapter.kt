package com.sadhin.cricketbash.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.Team.Team
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class TeamRankingAdapter(private val context: Context, private val viewModel: FixtureViewModel,private val t:String):
    RecyclerView.Adapter<TeamRankingAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View): RecyclerView.ViewHolder(view){
        val position: TextView =view.findViewById(R.id.ranking_pos)
        val name: TextView =view.findViewById(R.id.ranking_name)
        val matches: TextView =view.findViewById(R.id.ranking_matches)
        val point: TextView =view.findViewById(R.id.ranking_point)
        val rating: TextView =view.findViewById(R.id.ranking_rating)
        val country: ImageView =view.findViewById(R.id.ranking_image)
    }
    private var listOfTeam= emptyList<Team>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout= LayoutInflater.from(context).inflate(R.layout.team_list,parent,false)
        return ItemViewHolder(layout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos=listOfTeam[position]
        holder.name.text=pos.name
        holder.position.text= pos.ranking?.position.toString()
        holder.matches.text= pos.ranking?.matches.toString()
        holder.point.text= pos.ranking?.points.toString()
        holder.rating.text= pos.ranking?.rating.toString()
        Glide.with(holder.itemView.context)
            .load(pos.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.country)
        }

    override fun getItemCount(): Int { return listOfTeam.size }

    fun setTeam(temp:List<Team>?){
        if (temp !=null){ listOfTeam=temp }
        notifyDataSetChanged()
    }
}