package com.sadhin.cricketbash.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.league.Season
import com.sadhin.cricketbash.ui.LeagueFragmentDirections
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class LeagueSeasonAdapter(private val context: Context, private val viewModel: FixtureViewModel):
    RecyclerView.Adapter<LeagueSeasonAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View): RecyclerView.ViewHolder(view){
        val temp: TextView =view.findViewById(R.id.textView_season_list)
        val pos: TextView =view.findViewById(R.id.season_pos)
    }
    private var listOfLeague= emptyList<Season>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout= LayoutInflater.from(context).inflate(R.layout.season_list,parent,false)
        return ItemViewHolder(layout)
    }
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos=listOfLeague[position]
        holder.temp.text=pos.name.toString()
        holder.pos.text=position.toString()
        holder.itemView.setOnClickListener{
            val action= pos.league_id?.let { it1 ->
                pos.id?.let { it2 ->
                    LeagueFragmentDirections.actionLeagueFragmentToLeagueDetailFragment(
                        it1, it2
                    )
                }
            }
            if (action != null) { holder.itemView.findNavController().navigate(action) }
        }

    }

    override fun getItemCount(): Int { return listOfLeague.size }

    fun set(lineup:List<Season>?){
        if (lineup != null) { listOfLeague=lineup }
        notifyDataSetChanged()
    }
}