package com.sadhin.cricketbash.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList

@Dao
interface CricketDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFixtureRecent(fixture:List<FixtureRecentList>)


    @Query("select * from fixture_recent where strftime('%s', starting_at) <= strftime('%s', :date) order by starting_at desc")
    fun getFixtureRecent(date:String):LiveData<List<FixtureRecentList>>

    @Query("select * from fixture_recent where strftime('%s', starting_at) >= strftime('%s', :date) order by starting_at desc")
    fun getFixtureUpcoming(date:String):LiveData<List<FixtureRecentList>>

    @Query("select * from fixture_recent where id=:id")
    fun getFixtureId(id:Int):FixtureRecentList


}