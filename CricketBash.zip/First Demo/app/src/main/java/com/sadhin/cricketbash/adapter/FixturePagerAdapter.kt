package com.sadhin.cricketbash.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.sadhin.cricketbash.ui.FixtureRecentFragment
import com.sadhin.cricketbash.ui.FixtureUpcomingFragment

private const val NUMS_TAB = 3
class FixturePagerAdapter (fragmentManager: FragmentManager, lifecycle: Lifecycle):
    FragmentStateAdapter(fragmentManager, lifecycle){
    override fun getItemCount(): Int {return NUMS_TAB }
    override fun createFragment(position: Int): Fragment {
        return when(position){
            0 -> FixtureRecentFragment()
            1 -> FixtureUpcomingFragment()
            else -> FixtureRecentFragment()
        }
    }
}