package com.sadhin.cricketbash.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.tabs.TabLayoutMediator
import com.sadhin.cricketbash.adapter.TeamPagerAdapter
import com.sadhin.cricketbash.databinding.FragmentTeamBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class TeamFragment : Fragment() {
    private var _binding:FragmentTeamBinding? = null
    private  val binding get() = _binding!!
    private lateinit var viewModel: FixtureViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_team, container, false)
        _binding= FragmentTeamBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tabLayout=binding.tabLayoutTeam
        val viewPager=binding.pagerTeam
        val tabAdapter=TeamPagerAdapter(childFragmentManager,lifecycle)
        viewPager.adapter=tabAdapter
        TabLayoutMediator(tabLayout,viewPager){tab,position->
            when(position){
                0 -> tab.text = "T20I"
                1 -> tab.text = "ODI"
                else -> tab.text =  "TEST"
            }
        }.attach()
        viewModel.loadTeamRank()
    }

    companion object {
    }
}