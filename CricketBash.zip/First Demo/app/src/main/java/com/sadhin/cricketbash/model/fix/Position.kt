package com.sadhin.cricketbash.model.fix

data class Position(
    val id: Int?,
    val name: String?,
    val resource: String?
)