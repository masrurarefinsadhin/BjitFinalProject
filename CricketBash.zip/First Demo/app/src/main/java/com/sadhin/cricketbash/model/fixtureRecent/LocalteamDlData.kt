package com.sadhin.cricketbash.model.fixtureRecent

data class LocalteamDlData(
    val overs: String?,
    val rpc_overs: String?,
    val rpc_targets: String?,
    val score: String?,
    val wickets_out: String?
)