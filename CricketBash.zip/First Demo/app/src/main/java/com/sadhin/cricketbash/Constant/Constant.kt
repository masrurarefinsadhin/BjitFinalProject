package com.sadhin.cricketbash.Constant

class Constant {
    companion object{
        const val URL="https://cricket.sportmonks.com"
        const val TOKEN="FMRNjV3cC2q6xE31ya2oXBTizo4H1AMoYDXtPWszp62FBn6FMz7UAWXvaWWd"
        const val FIXTURE="fixture"
    }
}