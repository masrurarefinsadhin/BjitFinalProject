package com.sadhin.cricketbash.model.fixtureRecent

data class Links(
    val first: String?,
    val last: String?,
    val next: String?,
    val prev: Any?
)