package com.sadhin.cricketbash.model.fix

data class Fix(
    val `data`: Data?,
    val links: Links?,
    val meta: Meta?
)