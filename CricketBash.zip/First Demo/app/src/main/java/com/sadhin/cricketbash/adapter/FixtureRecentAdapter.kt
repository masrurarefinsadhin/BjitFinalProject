package com.sadhin.cricketbash.adapter

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R

import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList
import com.sadhin.cricketbash.ui.HomeFragmentDirections
import com.sadhin.cricketbash.viewmodel.FixtureViewModel
import java.text.SimpleDateFormat
import java.util.*

class FixtureRecentAdapter(private val context:Context, private val viewModel: FixtureViewModel):RecyclerView.Adapter<FixtureRecentAdapter.ItemViewHolder>() {
    class ItemViewHolder(view:View):RecyclerView.ViewHolder(view){
        val score:TextView=view.findViewById(R.id.textView_result)
        val date:TextView=view.findViewById(R.id.textView_date)
        val type:TextView=view.findViewById(R.id.textView_type)
        val localImageView:ImageView=view.findViewById(R.id.imageView_left)
        val visitorImageView:ImageView=view.findViewById(R.id.imageView_right)
        val localTextView:TextView=view.findViewById(R.id.textView_local_score)
        val visitorTextView:TextView=view.findViewById(R.id.textView_visitor_score)
        val localName:TextView=view.findViewById(R.id.textView_local_name)
        val visitorName:TextView=view.findViewById(R.id.textView_visitor_name)

    }
    private var listOfFixtures= emptyList<FixtureRecentList>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout=LayoutInflater.from(context).inflate(R.layout.fixture_list,parent,false)
        return ItemViewHolder(layout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos=listOfFixtures[position]
        holder.score.text=pos.note
        holder.date.text= pos.starting_at?.let { dateConvert(it) }
        holder.type.text="${pos.type}  ${pos.round}"
        holder.localName.text= pos.localteam?.name.toString()
        holder.visitorName.text= pos.visitorteam?.name.toString()
        if (pos.runs!!.size==2){
            if (pos.runs!![0].team_id==pos.localteam_id){
                holder.localTextView.text= "${pos.runs!![0].score}/${pos.runs!![0].wickets} (${pos.runs!![0].overs})"
                holder.visitorTextView.text= "${pos.runs!![1].score}/${pos.runs!![1].wickets} (${pos.runs!![1].overs})"
            }
            else{
                holder.visitorTextView.text= "${pos.runs!![0].score}/${pos.runs!![0].wickets} (${pos.runs!![0].overs})"
                holder.localTextView.text= "${pos.runs!![1].score}/${pos.runs!![1].wickets} (${pos.runs!![1].overs})"
            }
        }
        if (pos.localteam_id==pos.winner_team_id){
            holder.localName.setTypeface(null, Typeface.BOLD)
            holder.visitorName.setTypeface(null, Typeface.NORMAL)
            holder.localTextView.setTypeface(null, Typeface.BOLD)
            holder.visitorTextView.setTypeface(null, Typeface.NORMAL)
        }
        else if(pos.visitorteam_id==pos.winner_team_id){
            holder.visitorName.setTypeface(null, Typeface.BOLD)
            holder.localName.setTypeface(null, Typeface.NORMAL)
            holder.localTextView.setTypeface(null, Typeface.NORMAL)
            holder.visitorTextView.setTypeface(null, Typeface.BOLD)
        }
        Log.d("adapter", "onBindViewHolder: ${pos.runs}")
        Glide.with(holder.itemView.context)
            .load(pos.localteam?.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.localImageView)
        Glide.with(holder.itemView.context)
            .load(pos.visitorteam?.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.visitorImageView)

        holder.itemView.setOnClickListener {
            val action= pos.id?.let { it1 -> HomeFragmentDirections.actionHomeFragmentToFixtureDetailsFragment(it1) }
            if (action != null) { holder.itemView.findNavController().navigate(action) }
        }
    }
    override fun getItemCount(): Int { return listOfFixtures.size }
    fun setFixture(fixture:List<FixtureRecentList>){
        listOfFixtures=fixture
        notifyDataSetChanged()
    }
    private fun dateConvert(s:String):String?{
        val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'", Locale.US)
        val outputFormat = SimpleDateFormat("d MMMM yyyy", Locale.US)
        val inputDate = inputFormat.parse(s)
        return inputDate?.let { outputFormat.format(it) }
    }
}