package com.sadhin.cricketbash.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.sadhin.cricketbash.ui.LocalScoreFragment
import com.sadhin.cricketbash.ui.VisitorScoreFragment

private const val NUMS_TAB = 2
class FixtureDetailPagerAdapter (fragmentManager: FragmentManager, lifecycle: Lifecycle ):
    FragmentStateAdapter(fragmentManager, lifecycle){
    override fun getItemCount(): Int {
        return NUMS_TAB
    }
    override fun createFragment(position: Int): Fragment {
        if (position==0){
            return LocalScoreFragment()
        }
        else{return VisitorScoreFragment()
        }
    }
}