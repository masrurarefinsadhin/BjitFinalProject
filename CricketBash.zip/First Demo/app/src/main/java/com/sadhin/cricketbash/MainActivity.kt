package com.sadhin.cricketbash

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupActionBarWithNavController
import com.sadhin.cricketbash.databinding.ActivityMainBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var navController: NavController
    private var _binding: ActivityMainBinding?=null
    private val binding get() = _binding!!
    lateinit var mViewModel: FixtureViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        _binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mViewModel = ViewModelProvider(this)[FixtureViewModel::class.java]
        navControl()
        bottomNav()
    }
    private fun navControl(){
        val navHostFragment = supportFragmentManager.findFragmentById(binding.fragmentContainer.id) as NavHostFragment
        navController = navHostFragment.navController
        setupActionBarWithNavController(navController)
    }

    private fun bottomNav(){
        binding.bottomNavigation.setOnItemSelectedListener{
            when(it.itemId){
                R.id.home->{
                    navController.navigate(R.id.homeFragment)
                    true
                }
                R.id.league -> {
                    navController.navigate(R.id.leagueFragment)
                    true
                }
                R.id.team -> {
                    navController.navigate(R.id.teamFragment)
                    true
                }
                else-> false
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}