package com.sadhin.cricketbash.ui

import android.graphics.Typeface
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayoutMediator
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.adapter.FixtureDetailPagerAdapter
import com.sadhin.cricketbash.databinding.FragmentFixtureDetailsBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel
import java.text.SimpleDateFormat
import java.util.*

class FixtureDetailsFragment : Fragment() {
    private var _binding: FragmentFixtureDetailsBinding?=null
    private val binding get()= _binding!!
    private val navArgs:FixtureDetailsFragmentArgs by navArgs()

    private lateinit var viewModel: FixtureViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_fixture_details, container, false)
        _binding=FragmentFixtureDetailsBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tabLayout = binding.tabLayoutFixtureDetail
        val viewPager=binding.fixturePager
        val tabAdapter=FixtureDetailPagerAdapter(childFragmentManager,lifecycle)
        viewPager.adapter=tabAdapter
        TabLayoutMediator(tabLayout,viewPager) { tab, position->
            when(position){
                0-> tab.text = "Home "
                else-> tab.text = "Away"

            }
        }.attach()

        viewModel.loadFixtureDetails(navArgs.fixtureId)
        viewModel.loadFixtureId(navArgs.fixtureId)

        viewModel.fixtureId.observe(viewLifecycleOwner){ it ->
            tabLayout.getTabAt(0)?.text = it.localteam?.name
            tabLayout.getTabAt(1)?.text = it.visitorteam?.name
            binding.textViewLocalName.text= it.localteam?.name.toString()
            binding.textViewVisitorName.text= it.visitorteam?.name.toString()
            binding.textViewResult.text=it.note.toString()
            binding.textViewType.text="${it.type}  ${it.round}"
            if (it.runs!!.size==2){
                if (it.runs!![0].team_id==it.localteam_id){
                    binding.textViewLocalScore.text= "${it.runs!![0].score}/${it.runs!![0].wickets}(${it.runs!![0].overs})"
                    binding.textViewVisitorScore.text= "${it.runs!![1].score}/${it.runs!![1].wickets}(${it.runs!![1].overs})"
                }
                else{
                    binding.textViewVisitorScore.text= "${it.runs!![0].score}/${it.runs!![0].wickets}(${it.runs!![0].overs})"
                    binding.textViewLocalScore.text= "${it.runs!![1].score}/${it.runs!![1].wickets}(${it.runs!![1].overs})"
                }
            }

            if (it.localteam_id==it.winner_team_id){
                binding.textViewLocalName.setTypeface(null, Typeface.BOLD)
                binding.textViewVisitorName.setTypeface(null, Typeface.NORMAL)
                binding.textViewLocalScore.setTypeface(null, Typeface.BOLD)
                binding.textViewVisitorScore.setTypeface(null, Typeface.NORMAL)
            }
            else if(it.visitorteam_id==it.winner_team_id){
                binding.textViewVisitorName.setTypeface(null, Typeface.BOLD)
                binding.textViewLocalName.setTypeface(null, Typeface.NORMAL)
                binding.textViewLocalScore.setTypeface(null, Typeface.NORMAL)
                binding.textViewVisitorScore.setTypeface(null, Typeface.BOLD)
            }
            binding.textViewDate.text= it.starting_at?.let { dateConvert(it) }
            Glide.with(requireContext())
                .load(it.localteam?.image_path)
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(binding.imageViewLeft)
            Glide.with(requireContext())
                .load(it.visitorteam?.image_path)
                .placeholder(R.drawable.ic_launcher_foreground)
                .into(binding.imageViewRight)
        }
    }

    private fun dateConvert(s:String):String?{
        val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'", Locale.US)
        val outputFormat = SimpleDateFormat("d MMMM yyyy", Locale.US)
        val inputDate = inputFormat.parse(s)
        return inputDate?.let { outputFormat.format(it) }

    }

    companion object {}
}