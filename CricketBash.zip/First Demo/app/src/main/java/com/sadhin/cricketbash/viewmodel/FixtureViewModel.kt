package com.sadhin.cricketbash.viewmodel
import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.sadhin.cricketbash.data.CricketDatabase
import com.sadhin.cricketbash.data.CricketRepository
import com.sadhin.cricketbash.model.Team.Team
import com.sadhin.cricketbash.model.fix.Batting
import com.sadhin.cricketbash.model.fix.Bowling
import com.sadhin.cricketbash.model.fix.Lineup
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList
import com.sadhin.cricketbash.model.league.Data
import com.sadhin.cricketbash.model.league.Season
import com.sadhin.cricketbash.network.CricketApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
class FixtureViewModel(application: Application): AndroidViewModel(application) {
    private val repository: CricketRepository

    var fixtureRecent: LiveData<List<FixtureRecentList>>
    var fixtureUpcoming: LiveData<List<FixtureRecentList>>

    //league
    var leagueList=MutableLiveData<List<Data>?>()
    var leagueSeasonList=MutableLiveData<List<Season>?>()
    var leagueFixture=MutableLiveData<List<FixtureRecentList>?>()

    //fixturedetails
    val _fixtureBattingLocal = MutableLiveData<List<Batting>>()
    val fixtureBattingLocal get()=_fixtureBattingLocal

    val _fixtureBattingVisitor = MutableLiveData<List<Batting>>()
    var fixtureBattingVisitor =_fixtureBattingVisitor

    val _fixtureBowlingLocal = MutableLiveData<List<Bowling>>()
    var fixtureBowlingLocal =_fixtureBowlingLocal

    val _fixtureBowlingVisitor = MutableLiveData<List<Bowling>>()
    var fixtureBowlingVisitor =_fixtureBowlingVisitor

    val _fixtureId=MutableLiveData<FixtureRecentList>()
    var fixtureId =_fixtureId

    val _lineupLocal=MutableLiveData<List<Lineup>>()
    var lineupLocal =_lineupLocal

    val _lineupVisitor=MutableLiveData<List<Lineup>>()
    var lineupVisitor =_lineupVisitor

    //Ranking
    val _ranking=MutableLiveData<List<Team>>()
    val ranking  = _ranking
    val _rankingTwo=MutableLiveData<List<Team>>()
    val rankingTwo  = _rankingTwo
    val _rankingThree=MutableLiveData<List<Team>>()
    val rankingThree  = _rankingThree

    //Connection
    private val connectivityManager =
        application.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            // Network is available
            Toast.makeText(getApplication(), "Internet Connection Established", Toast.LENGTH_SHORT).show()
        }
        override fun onLost(network: Network) {
            // Network is lost
            Toast.makeText(getApplication(), "Internet Connection Lost", Toast.LENGTH_SHORT).show()
        }
    }

    init {
        repository = CricketRepository(CricketDatabase.getDatabase(application).CricketDao())
        fixtureRecentLoad()
        fixtureRecent = repository.fixtureRecent
        fixtureUpcoming=repository.fixtureUpcoming
        Log.d("fixture_recent", "fixtureRecentLoad: ${fixtureRecent.value}")

        val networkRequest = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        connectivityManager.registerNetworkCallback(networkRequest, networkCallback)
    }

    fun loadTeamRank() {

        viewModelScope.launch(Dispatchers.IO) {
            try{
            val team = CricketApi.retrofitService.getTeamRank()
            for (i in team.data!!) {
                when (i.type) {
                    "TEST" -> {
                        if (i.team!!.isNotEmpty()) {
                            _rankingThree.postValue(i.team!!)
                        }
                    }
                    "T20I" -> {
                        if (i.team!!.isNotEmpty()) {
                            _ranking.postValue(i.team!!)
                        }
                    }
                    "ODI" -> {
                        if (i.team!!.isNotEmpty()) {
                            _rankingTwo.postValue(i.team!!)
                        }
                    }
                }
            }
        }catch (_:Exception) {
            }
    }
    }

    fun loadFixtureId(id:Int){
        viewModelScope.launch(Dispatchers.IO) {
            _fixtureId.postValue(repository.getFixtureId(id))
        }
    }

    private fun fixtureRecentLoad() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val time = "${getTime(-30)},${getTime(30)}"
                Log.d("time", "fixtureRecentLoad: $time")
                val fixture = CricketApi.retrofitService.getFixtureRecent(time)
                repository.addFixtureRecent(fixture.data)
            } catch (_: Exception) {
            }
        }
    }

    fun loadFixtureDetails(fixture_id: Int) {
        viewModelScope.launch (Dispatchers.Default){
            try{
            val details = CricketApi.retrofitService.getFixtureId(fixture_id)
            Log.d("batiing", "loadFixtureDetails: details$details")


            val batLocal= mutableListOf<Batting>()
            val batVisitor= mutableListOf<Batting>()
            val local=details.data!!.localteam_id
            for (i in details.data.batting!!){
                if (i.team_id==local){ batLocal.add(i)}
                else{batVisitor.add(i)}
            }
            _fixtureBattingLocal.postValue(batLocal)
            _fixtureBattingVisitor.postValue(batVisitor)

            val bowLocal= mutableListOf<Bowling>()
            val bowVisitor= mutableListOf<Bowling>()
            for (i in details.data.bowling!!){
                if (i.team_id==local){ bowLocal.add(i)}
                else{bowVisitor.add(i)}
            }
            _fixtureBowlingLocal.postValue(bowLocal)
            _fixtureBowlingVisitor.postValue(bowVisitor)

            val lineLocal= mutableListOf<Lineup>()
            val lineVisitor= mutableListOf<Lineup>()
            for (i in details.data.lineup!!){
                if (i.lineup?.team_id ==local){ lineLocal.add(i)}
                else{lineVisitor.add(i)}
            }
            _lineupLocal.postValue(lineLocal)
            _lineupVisitor.postValue(lineVisitor)
            } catch (_: Exception) {
            }
        }

    }

    fun loadLeagueList(){
        viewModelScope.launch (Dispatchers.IO){
            try{
            val league= CricketApi.retrofitService.getLeagues()
            leagueList.postValue(league.data)
            leagueSeasonList.postValue(league.data!![0].seasons?.sortedByDescending { it.updated_at })
            } catch (_: Exception) {
            }
            }
    }
    fun loadLeagueDetail(league_id:Int,season_id:Int){
        viewModelScope.launch (Dispatchers.IO){
            try {
            val detail= CricketApi.retrofitService.getLeaguesDetail(league_id,season_id)
            leagueFixture.postValue(detail.data.sortedBy { it.starting_at })
            } catch (_: Exception) {
            }
            }
    }

    fun loadSeasonList(league_id:Int){
        viewModelScope.launch (Dispatchers.IO){
            try {

            Log.d("seasonlist", "loadSeasonList:${league_id} ")
            Log.d("seasonlist", "loadSeasonList:${leagueList.value} ")
            for (i in leagueList.value!!){
                if (i.id==league_id){
                    leagueSeasonList.postValue(i.seasons?.sortedByDescending { it.updated_at })

                } }
            } catch (_: Exception) {
            }
            }
    }
    fun getTime(days:Int):String{
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, days)
        val futureDate = calendar.time
        val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return formatter.format(futureDate)
    }
    override fun onCleared() {
        super.onCleared()
        connectivityManager.unregisterNetworkCallback(networkCallback)
    }
}