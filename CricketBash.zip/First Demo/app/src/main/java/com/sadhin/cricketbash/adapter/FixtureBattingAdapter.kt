package com.sadhin.cricketbash.adapter
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.fix.Batting
import com.sadhin.cricketbash.viewmodel.FixtureViewModel

class FixtureBattingAdapter(private val context: Context, private val viewModel: FixtureViewModel):
    RecyclerView.Adapter<FixtureBattingAdapter.ItemViewHolder>() {
    class ItemViewHolder(view: View): RecyclerView.ViewHolder(view){
        val image:ImageView=view.findViewById(R.id.batting_image)
        val name:TextView=view.findViewById(R.id.batting_name)
        val run:TextView=view.findViewById(R.id.batting_run)
        val ball:TextView=view.findViewById(R.id.batting_ball)
        val six:TextView=view.findViewById(R.id.batting_six)
        val four:TextView=view.findViewById(R.id.batting_four)
        val sr:TextView=view.findViewById(R.id.batting_SR)
    }
    private var batting= emptyList<Batting>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout= LayoutInflater.from(context).inflate(R.layout.batting_list,parent,false)
        return ItemViewHolder(layout)
    }
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos= batting[position]
        Log.d("batting", "onBindViewHolder: $pos")
            holder.name.text=pos.batsman?.firstname
            holder.run.text= pos.score.toString()
            holder.ball.text= pos.ball.toString()
            holder.six.text=pos.six_x.toString()
            holder.four.text=pos.four_x.toString()
            holder.sr.text=String.format("%.1f", pos.rate)
        Glide.with(holder.itemView.context)
            .load(pos.batsman!!.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.image)
    }
    override fun getItemCount(): Int { return batting.size
    }
    fun setData(f:List<Batting>?){
        Log.d("batting", "setData: $f")
        if (f != null) { batting= f }
        notifyDataSetChanged()
    }
}