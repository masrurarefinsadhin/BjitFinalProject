package com.sadhin.cricketbash.model.Team

data class Ranking(
    val matches: Int?,
    val points: Int?,
    val position: Int?,
    val rating: Int?
)