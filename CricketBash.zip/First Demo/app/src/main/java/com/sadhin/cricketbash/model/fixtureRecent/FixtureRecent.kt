package com.sadhin.cricketbash.model.fixtureRecent

import com.squareup.moshi.Json
data class FixtureRecent(
    @field:Json(name = "data")
    val `data`: List<FixtureRecentList>,
    val links: Links,
    val meta: Meta
)