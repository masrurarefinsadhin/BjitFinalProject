package com.sadhin.cricketbash.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sadhin.cricketbash.adapter.FixtureUpcomingAdapter

import com.sadhin.cricketbash.databinding.FragmentFixtureUpcomingBinding
import com.sadhin.cricketbash.viewmodel.FixtureViewModel


class FixtureUpcomingFragment : Fragment() {
    private var _binding: FragmentFixtureUpcomingBinding?=null
    private  val binding get()=_binding!!
    private lateinit var recyclerView: RecyclerView
    private lateinit var viewModel: FixtureViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        //return inflater.inflate(R.layout.fragment_fixture_recent, container, false)
        _binding=FragmentFixtureUpcomingBinding.inflate(inflater,container,false)
        viewModel = ViewModelProvider(requireActivity())[FixtureViewModel::class.java]
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView=binding.recyclerViewFixtureUpcoming
        recyclerView.layoutManager= LinearLayoutManager(context)
        val adapter= FixtureUpcomingAdapter(requireContext(),viewModel)
        recyclerView.adapter=adapter
        viewModel.fixtureUpcoming.observe(viewLifecycleOwner){ adapter.setFixture(it) }
    }
    companion object {}
}