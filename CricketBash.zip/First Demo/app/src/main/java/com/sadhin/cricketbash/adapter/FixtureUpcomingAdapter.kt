package com.sadhin.cricketbash.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.sadhin.cricketbash.R
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecentList
import com.sadhin.cricketbash.viewmodel.FixtureViewModel
import java.text.SimpleDateFormat
import java.util.*

class FixtureUpcomingAdapter(private val context:Context, private val viewModel: FixtureViewModel):RecyclerView.Adapter<FixtureUpcomingAdapter.ItemViewHolder>() {
    class ItemViewHolder(view:View):RecyclerView.ViewHolder(view){
        val localImageView:ImageView=view.findViewById(R.id.imageView_right)
        val visitorImageView:ImageView=view.findViewById(R.id.imageView_right)
        val date:TextView=view.findViewById(R.id.textView_date)
        val type:TextView=view.findViewById(R.id.textView_type)
        val localName:TextView=view.findViewById(R.id.textView_local_name)
        val visitorName:TextView=view.findViewById(R.id.textView_visitor_name)

    }
    private var listOfFixtures= emptyList<FixtureRecentList>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val layout=LayoutInflater.from(context).inflate(R.layout.fixture_upcoming_list,parent,false)
        return ItemViewHolder(layout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val pos=listOfFixtures[position]
        holder.type.text="${pos.type}  ${pos.round}"
        holder.date.text= pos.starting_at?.let { dateConvert(it) }
        holder.localName.text= pos.localteam?.name.toString()
        holder.visitorName.text= pos.visitorteam?.name.toString()

        Glide.with(holder.itemView.context)
            .load(pos.localteam?.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.localImageView)
        Glide.with(holder.itemView.context)
            .load(pos.visitorteam?.image_path)
            .placeholder(R.drawable.ic_launcher_foreground)
            .into(holder.visitorImageView)
    }

    override fun getItemCount(): Int { return listOfFixtures.size }
    fun setFixture(fixture:List<FixtureRecentList>){
        listOfFixtures=fixture
        notifyDataSetChanged()
    }

    private fun dateConvert(s:String):String?{
        val inputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'", Locale.US)
        val outputFormat = SimpleDateFormat("d MMMM yyyy", Locale.US)
        val inputDate = inputFormat.parse(s)
        return inputDate?.let { outputFormat.format(it) }
    }
}