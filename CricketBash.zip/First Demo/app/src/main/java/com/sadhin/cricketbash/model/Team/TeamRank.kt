package com.sadhin.cricketbash.model.Team

data class TeamRank(
    val `data`: List<Data>?
)