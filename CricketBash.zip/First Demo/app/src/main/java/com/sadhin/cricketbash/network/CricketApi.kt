package com.sadhin.cricketbash.network

import com.sadhin.cricketbash.Constant.Constant.Companion.TOKEN
import com.sadhin.cricketbash.Constant.Constant.Companion.URL
import com.sadhin.cricketbash.model.Team.TeamRank
import com.sadhin.cricketbash.model.fix.Fix
import com.sadhin.cricketbash.model.fixtureRecent.FixtureRecent
import com.sadhin.cricketbash.model.league.League
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

private val moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()
private val retrofit = Retrofit.Builder()
    .addConverterFactory(MoshiConverterFactory.create(moshi))
    .baseUrl(URL)
    .build()
interface CricketApiService{

    @GET("$URL/api/v2.0/fixtures?include=runs,localteam,visitorteam&api_token=$TOKEN")
    suspend fun getFixtureRecent(
        @Query("filter[starts_between]") p1: String
    ):FixtureRecent

    @GET("$URL/api/v2.0/fixtures/{FIXTURE_ID}?include=runs,scoreboards,batting.batsman,bowling.bowler,lineup&api_token=$TOKEN")
    suspend fun getFixtureId(
        @Path(value = "FIXTURE_ID", encoded = false) key: Int
    ): Fix

    @GET("$URL/api/v2.0/leagues?include=country,seasons&api_token=$TOKEN")
    suspend fun getLeagues():League

    @GET("$URL/api/v2.0/fixtures?include=runs,localteam,visitorteam&sort=starting_at&api_token=$TOKEN")
    suspend fun getLeaguesDetail(
        @Query("filter[league_id]") p1: Int, @Query("filter[season_id]") p2: Int
    ):FixtureRecent

    @GET("$URL/api/v2.0/team-rankings?filter[gender]=men&api_token=$TOKEN")
    suspend fun getTeamRank():TeamRank


}
object CricketApi{
    val retrofitService: CricketApiService by lazy {
        retrofit.create(CricketApiService::class.java)
    }
}
